package com.procesos.negocio.harold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcesosApplicationTests {

	@Test
	void contextLoads() {
	}

}
