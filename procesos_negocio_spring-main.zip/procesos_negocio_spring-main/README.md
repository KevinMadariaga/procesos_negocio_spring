# procesos_negocio_spring
proyecto para la clase de procesos de negocio usando el framework de spring boot
